import { Home, ListTodo, CalendarDays, FolderKanban, BarChart3, Settings, LogOut, CheckCircle2 } from 'lucide-react';
import type { PageName } from '@/types';
import { useAuth } from '@/lib/auth';

interface Props {
  current: PageName;
  onNavigate: (p: PageName) => void;
}

const items: { id: PageName; label: string; icon: typeof Home }[] = [
  { id: 'home', label: 'Home', icon: Home },
  { id: 'tasks', label: 'Tasks', icon: ListTodo },
  { id: 'calendar', label: 'Calendar', icon: CalendarDays },
  { id: 'categories', label: 'Categories', icon: FolderKanban },
  { id: 'progress', label: 'Progress', icon: BarChart3 },
];

export function Sidebar({ current, onNavigate }: Props) {
  const { profile, signOut } = useAuth();
  const initials = (profile?.name || 'T M').split(' ').map(w => w[0]).slice(0, 2).join('');

  return (
    <aside className="hidden md:flex flex-col w-[220px] shrink-0 bg-[#F5EDFA] rounded-r-[36px] p-5 h-screen sticky top-0">
      <div className="flex items-center gap-2 px-2 py-3">
        <div className="w-9 h-9 rounded-2xl bg-[#7653A6] flex items-center justify-center">
          <CheckCircle2 size={20} className="text-white" />
        </div>
        <span className="font-display text-xl font-extrabold text-[#292238]">Tasky</span>
      </div>
      <nav className="flex-1 mt-6 space-y-1">
        {items.map(it => {
          const Icon = it.icon;
          const active = current === it.id;
          return (
            <button
              key={it.id}
              onClick={() => onNavigate(it.id)}
              className={`w-full flex items-center gap-3 px-3.5 py-2.5 rounded-2xl text-sm font-semibold transition-all ${active ? 'bg-[#7653A6] text-white shadow-sm shadow-[#7653A6]/25' : 'text-[#6B5B7E] hover:bg-[#EDE0F5]'}`}
            >
              <Icon size={18} />
              {it.label}
            </button>
          );
        })}
      </nav>
      <div className="space-y-3">
        <button
          onClick={() => onNavigate('settings')}
          className={`w-full flex items-center gap-3 px-3.5 py-2.5 rounded-2xl text-sm font-semibold transition-all ${current === 'settings' ? 'bg-[#7653A6] text-white' : 'text-[#6B5B7E] hover:bg-[#EDE0F5]'}`}
        >
          <Settings size={18} /> Settings
        </button>
        <div className="flex items-center gap-3 px-2 py-2 rounded-2xl bg-white/60">
          <div className="w-9 h-9 rounded-full bg-[#E8D5F2] flex items-center justify-center text-sm font-bold text-[#7653A6]">
            {initials}
          </div>
          <div className="min-w-0 flex-1">
            <p className="text-sm font-semibold text-[#292238] truncate">{profile?.name || 'Task Master'}</p>
            <p className="text-xs text-[#9B8BAD]">Task Master</p>
          </div>
          <button onClick={signOut} className="p-1.5 rounded-full hover:bg-[#FDECEC] text-[#C0473F]" aria-label="Log out">
            <LogOut size={16} />
          </button>
        </div>
      </div>
    </aside>
  );
}
