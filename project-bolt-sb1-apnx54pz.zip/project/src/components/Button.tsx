import { type ButtonHTMLAttributes, type ReactNode } from 'react';

type Variant = 'primary' | 'secondary' | 'ghost' | 'danger';
type Size = 'sm' | 'md' | 'lg';

interface Props extends ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: Variant;
  size?: Size;
  children: ReactNode;
}

const variants: Record<Variant, string> = {
  primary: 'bg-[#7653A6] text-white hover:bg-[#6948a0] active:bg-[#5d3d92] shadow-sm shadow-[#7653A6]/30',
  secondary: 'bg-white text-[#7653A6] border border-[#E5DBF5] hover:bg-[#F8F3FE]',
  ghost: 'text-[#7653A6] hover:bg-[#F2E9FA]',
  danger: 'bg-[#FDECEC] text-[#C0473F] hover:bg-[#FBE0E0] border border-[#F5D0CE]',
};

const sizes: Record<Size, string> = {
  sm: 'px-3.5 py-2 text-sm rounded-xl gap-1.5',
  md: 'px-5 py-2.5 text-sm rounded-2xl gap-2',
  lg: 'px-6 py-3.5 text-base rounded-2xl gap-2',
};

export function Button({ variant = 'primary', size = 'md', className = '', children, ...rest }: Props) {
  return (
    <button
      className={`inline-flex items-center justify-center font-semibold transition-all duration-200 disabled:opacity-50 disabled:pointer-events-none ${variants[variant]} ${sizes[size]} ${className}`}
      {...rest}
    >
      {children}
    </button>
  );
}
