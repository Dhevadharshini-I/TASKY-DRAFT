import { type InputHTMLAttributes, type ReactNode, forwardRef } from 'react';

interface Props extends InputHTMLAttributes<HTMLInputElement> {
  label?: string;
  error?: string;
  rightSlot?: ReactNode;
}

export const Input = forwardRef<HTMLInputElement, Props>(function Input(
  { label, error, rightSlot, className = '', id, ...rest },
  ref
) {
  const inputId = id || rest.name || label;
  return (
    <div className="w-full">
      {label && <label htmlFor={inputId} className="block text-sm font-semibold text-[#5B4B6E] mb-1.5">{label}</label>}
      <div className="relative">
        <input
          ref={ref}
          id={inputId}
          className={`w-full px-4 py-3 bg-white rounded-2xl border text-[#292238] placeholder:text-[#B5A8C8] transition-colors ${error ? 'border-[#E5A8A4]' : 'border-[#E5DBF5] focus:border-[#7653A6]'} outline-none ${rightSlot ? 'pr-12' : ''} ${className}`}
          {...rest}
        />
        {rightSlot && <div className="absolute right-3 top-1/2 -translate-y-1/2">{rightSlot}</div>}
      </div>
      {error && <p className="mt-1 text-sm text-[#C0473F]">{error}</p>}
    </div>
  );
});
