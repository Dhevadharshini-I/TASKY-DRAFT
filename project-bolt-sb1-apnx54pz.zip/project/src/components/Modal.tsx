import { type ReactNode, useEffect } from 'react';
import { X } from 'lucide-react';

interface Props {
  open: boolean;
  onClose: () => void;
  title: string;
  children: ReactNode;
  footer?: ReactNode;
}

export function Modal({ open, onClose, title, children, footer }: Props) {
  useEffect(() => {
    if (!open) return;
    const handler = (e: KeyboardEvent) => { if (e.key === 'Escape') onClose(); };
    window.addEventListener('keydown', handler);
    document.body.style.overflow = 'hidden';
    return () => { window.removeEventListener('keydown', handler); document.body.style.overflow = ''; };
  }, [open, onClose]);

  if (!open) return null;
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      <div className="absolute inset-0 bg-[#2E1F43]/40 backdrop-blur-sm fade-in" onClick={onClose} />
      <div className="relative bg-white rounded-3xl soft-shadow w-full max-w-lg max-h-[90vh] overflow-y-auto modal-in">
        <div className="flex items-center justify-between px-6 pt-5 pb-3">
          <h2 className="font-display text-xl font-bold text-[#292238]">{title}</h2>
          <button onClick={onClose} className="p-2 rounded-full hover:bg-[#F2E9FA] text-[#7B6B8E]" aria-label="Close">
            <X size={20} />
          </button>
        </div>
        <div className="px-6 pb-2">{children}</div>
        {footer && <div className="flex justify-end gap-3 px-6 py-4 mt-2">{footer}</div>}
      </div>
    </div>
  );
}
