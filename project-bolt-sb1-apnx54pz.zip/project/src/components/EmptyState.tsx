import { type ReactNode } from 'react';

interface Props { icon?: ReactNode; title: string; subtitle?: string; action?: ReactNode; }

export function EmptyState({ icon, title, subtitle, action }: Props) {
  return (
    <div className="flex flex-col items-center justify-center text-center py-16 px-6">
      {icon && <div className="mb-4 text-[#B5A8C8]">{icon}</div>}
      <h3 className="font-display text-lg font-bold text-[#292238]">{title}</h3>
      {subtitle && <p className="mt-1 text-sm text-[#7B6B8E]">{subtitle}</p>}
      {action && <div className="mt-5">{action}</div>}
    </div>
  );
}
