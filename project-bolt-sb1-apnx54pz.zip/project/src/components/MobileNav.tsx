import { Home, ListTodo, CalendarDays, FolderKanban, BarChart3, CheckCircle2 } from 'lucide-react';
import type { PageName } from '@/types';

interface Props {
  current: PageName;
  onNavigate: (p: PageName) => void;
}

const items: { id: PageName; label: string; icon: typeof Home }[] = [
  { id: 'home', label: 'Home', icon: Home },
  { id: 'tasks', label: 'Tasks', icon: ListTodo },
  { id: 'calendar', label: 'Calendar', icon: CalendarDays },
  { id: 'categories', label: 'Categories', icon: FolderKanban },
  { id: 'progress', label: 'Progress', icon: BarChart3 },
];

export function MobileNav({ current, onNavigate }: Props) {
  return (
    <>
      <div className="md:hidden flex items-center gap-2 px-4 py-3 bg-[#F5EDFA] sticky top-0 z-30">
        <div className="w-8 h-8 rounded-xl bg-[#7653A6] flex items-center justify-center">
          <CheckCircle2 size={18} className="text-white" />
        </div>
        <span className="font-display text-lg font-extrabold text-[#292238]">Tasky</span>
      </div>
      <nav className="md:hidden fixed bottom-0 inset-x-0 bg-white border-t border-[#F0E8F8] flex justify-around px-2 py-2 z-40">
        {items.map(it => {
          const Icon = it.icon;
          const active = current === it.id;
          return (
            <button
              key={it.id}
              onClick={() => onNavigate(it.id)}
              className={`flex flex-col items-center gap-0.5 px-3 py-1.5 rounded-2xl text-[10px] font-semibold transition-colors ${active ? 'text-[#7653A6]' : 'text-[#9B8BAD]'}`}
            >
              <Icon size={20} />
              {it.label}
            </button>
          );
        })}
      </nav>
    </>
  );
}
