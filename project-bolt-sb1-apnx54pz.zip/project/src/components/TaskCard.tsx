import { GripVertical, Clock, Tag, Pencil, Trash2 } from 'lucide-react';
import type { Task, Priority } from '@/types';

interface Props {
  task: Task;
  onToggle: () => void;
  onEdit: () => void;
  onDelete: () => void;
  onDragStart: () => void;
  draggable: boolean;
}

const priorityColors: Record<Priority, string> = { high: '#E89B8B', medium: '#F0C674', low: '#8FC9A8' };
const priorityLabels: Record<Priority, string> = { high: 'High Priority', medium: 'Medium Priority', low: 'Low Priority' };

const categoryColors: Record<string, string> = {
  Personal: '#E8D5F2', Work: '#D5E5F2', Study: '#D5F2E5', Health: '#F2E5D5', Shopping: '#F2D5E5',
};

export function TaskCard({ task, onToggle, onEdit, onDelete, onDragStart, draggable }: Props) {
  return (
    <div
      draggable={draggable}
      onDragStart={onDragStart}
      className={`group flex items-start gap-3 bg-white rounded-3xl px-5 py-4 border border-[#F0E8F8] card-hover ${task.completed ? 'opacity-60' : ''}`}
    >
      <div className="flex items-center self-center text-[#D4C5E8] cursor-grab" aria-hidden>
        <GripVertical size={18} />
      </div>
      <button
        onClick={onToggle}
        aria-label={task.completed ? 'Mark as not done' : 'Mark as done'}
        className={`mt-0.5 w-6 h-6 rounded-full border-2 flex items-center justify-center transition-all shrink-0 ${task.completed ? 'bg-[#7653A6] border-[#7653A6]' : 'border-[#D4C5E8] hover:border-[#7653A6]'}`}
      >
        {task.completed && (
          <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="4" strokeLinecap="round" strokeLinejoin="round"><polyline points="20 6 9 17 4 12" /></svg>
        )}
      </button>
      <div className="flex-1 min-w-0 cursor-pointer" onClick={onEdit}>
        <p className={`font-semibold text-[#292238] ${task.completed ? 'line-through text-[#B5A8C8]' : ''}`}>{task.title}</p>
        <div className="flex flex-wrap items-center gap-2 mt-1.5">
          <span className="inline-flex items-center gap-1 text-xs font-medium px-2 py-0.5 rounded-full" style={{ background: `${priorityColors[task.priority]}22`, color: '#7B5C8E' }}>
            <span className="w-2 h-2 rounded-full" style={{ background: priorityColors[task.priority] }} />
            {priorityLabels[task.priority]}
          </span>
          {task.due_time && (
            <span className="inline-flex items-center gap-1 text-xs text-[#7B6B8E]"><Clock size={12} /> Due {task.due_time}</span>
          )}
          <span className="inline-flex items-center gap-1 text-xs px-2 py-0.5 rounded-full" style={{ background: categoryColors[task.category] || '#F2E9FA', color: '#6B5B7E' }}>
            <Tag size={11} /> {task.category}
          </span>
        </div>
      </div>
      <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
        <button onClick={onEdit} className="p-2 rounded-full hover:bg-[#F2E9FA] text-[#7B6B8E]" aria-label="Edit task"><Pencil size={15} /></button>
        <button onClick={onDelete} className="p-2 rounded-full hover:bg-[#FDECEC] text-[#C0473F]" aria-label="Delete task"><Trash2 size={15} /></button>
      </div>
    </div>
  );
}
