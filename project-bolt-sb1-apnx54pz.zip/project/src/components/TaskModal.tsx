import { useEffect, useState } from 'react';
import { Modal } from './Modal';
import { Button } from './Button';
import { Input } from './Input';
import type { Task, Priority } from '@/types';

interface Props {
  open: boolean;
  onClose: () => void;
  onSave: (data: Partial<Task>) => Promise<void>;
  task?: Task | null;
  defaultDate?: string;
}

const priorities: { value: Priority; label: string; color: string }[] = [
  { value: 'low', label: 'Low', color: '#8FC9A8' },
  { value: 'medium', label: 'Medium', color: '#F0C674' },
  { value: 'high', label: 'High', color: '#E89B8B' },
];

const categories = ['Personal', 'Work', 'Study', 'Health', 'Shopping'];

export function TaskModal({ open, onClose, onSave, task, defaultDate }: Props) {
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [dueDate, setDueDate] = useState('');
  const [dueTime, setDueTime] = useState('');
  const [priority, setPriority] = useState<Priority>('medium');
  const [category, setCategory] = useState('Personal');
  const [reminder, setReminder] = useState(false);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState('');

  useEffect(() => {
    if (task) {
      setTitle(task.title);
      setDescription(task.description);
      setDueDate(task.due_date || '');
      setDueTime(task.due_time || '');
      setPriority(task.priority);
      setCategory(task.category);
      setReminder(task.reminder);
    } else {
      setTitle(''); setDescription(''); setDueDate(defaultDate || ''); setDueTime(''); setPriority('medium'); setCategory('Personal'); setReminder(false);
    }
    setError('');
  }, [task, open, defaultDate]);

  async function handleSave() {
    if (!title.trim()) { setError('Please give your task a title.'); return; }
    setSaving(true);
    try {
      await onSave({
        title: title.trim(),
        description: description.trim(),
        due_date: dueDate || null,
        due_time: dueTime || null,
        priority,
        category,
        reminder,
      });
      onClose();
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Something went wrong.');
    } finally {
      setSaving(false);
    }
  }

  return (
    <Modal
      open={open}
      onClose={onClose}
      title={task ? 'Edit task' : 'New task'}
      footer={
        <>
          <Button variant="secondary" onClick={onClose}>Cancel</Button>
          <Button onClick={handleSave} disabled={saving}>{saving ? 'Saving…' : task ? 'Save changes' : 'Create task'}</Button>
        </>
      }
    >
      <div className="space-y-4">
        <Input label="Task title" name="title" placeholder="e.g. Finish project report" value={title} onChange={e => setTitle(e.target.value)} error={error} autoFocus />
        <div>
          <label className="block text-sm font-semibold text-[#5B4B6E] mb-1.5">Description</label>
          <textarea
            className="w-full px-4 py-3 bg-white rounded-2xl border border-[#E5DBF5] focus:border-[#7653A6] outline-none text-[#292238] placeholder:text-[#B5A8C8] min-h-[80px] resize-none"
            placeholder="Add a few details…"
            value={description}
            onChange={e => setDescription(e.target.value)}
          />
        </div>
        <div className="grid grid-cols-2 gap-3">
          <Input label="Due date" name="due_date" type="date" value={dueDate} onChange={e => setDueDate(e.target.value)} />
          <Input label="Due time" name="due_time" type="time" value={dueTime} onChange={e => setDueTime(e.target.value)} />
        </div>
        <div>
          <label className="block text-sm font-semibold text-[#5B4B6E] mb-1.5">Priority</label>
          <div className="flex gap-2">
            {priorities.map(p => (
              <button
                key={p.value}
                onClick={() => setPriority(p.value)}
                className={`flex-1 px-3 py-2.5 rounded-2xl border text-sm font-semibold transition-all ${priority === p.value ? 'border-[#7653A6] bg-[#F8F3FE] text-[#7653A6]' : 'border-[#E5DBF5] text-[#7B6B8E] hover:bg-[#FAF3FC]'}`}
              >
                <span className="inline-block w-2.5 h-2.5 rounded-full mr-2" style={{ background: p.color }} />
                {p.label}
              </button>
            ))}
          </div>
        </div>
        <div>
          <label className="block text-sm font-semibold text-[#5B4B6E] mb-1.5">Category</label>
          <select
            className="w-full px-4 py-3 bg-white rounded-2xl border border-[#E5DBF5] focus:border-[#7653A6] outline-none text-[#292238]"
            value={category}
            onChange={e => setCategory(e.target.value)}
          >
            {categories.map(c => <option key={c} value={c}>{c}</option>)}
          </select>
        </div>
        <label className="flex items-center gap-3 cursor-pointer select-none">
          <button
            type="button"
            onClick={() => setReminder(r => !r)}
            className={`relative w-11 h-6 rounded-full transition-colors ${reminder ? 'bg-[#7653A6]' : 'bg-[#E5DBF5]'}`}
            aria-pressed={reminder}
          >
            <span className={`absolute top-0.5 left-0.5 w-5 h-5 bg-white rounded-full transition-transform ${reminder ? 'translate-x-5' : ''}`} />
          </button>
          <span className="text-sm font-medium text-[#5B4B6E]">Send me a reminder</span>
        </label>
      </div>
    </Modal>
  );
}
