import { useState } from 'react';
import { Eye, EyeOff, CheckCircle2 } from 'lucide-react';
import { supabase } from '@/lib/supabase';
import { Button } from '@/components/Button';
import { Input } from '@/components/Input';
import { useToast } from '@/components/Toast';

export function SignupPage({ onSwitch }: { onSwitch: () => void }) {
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [confirm, setConfirm] = useState('');
  const [showPw, setShowPw] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const { notify } = useToast();

  const pwChecks = [
    { label: 'At least 6 characters', ok: password.length >= 6 },
    { label: 'One letter', ok: /[a-z]/i.test(password) },
    { label: 'One number', ok: /\d/.test(password) },
  ];

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError('');
    if (!name.trim()) { setError('Please enter your name.'); return; }
    if (!email.includes('@')) { setError('Please enter a valid email.'); return; }
    if (!pwChecks.every(c => c.ok)) { setError('Password doesn\'t meet the requirements.'); return; }
    if (password !== confirm) { setError('Passwords don\'t match.'); return; }
    setLoading(true);
    try {
      const { data, error } = await supabase.auth.signUp({
        email,
        password,
        options: { data: { name: name.trim() } },
      });
      if (error) throw error;
      if (data.user) {
        await supabase.from('profiles').insert({ id: data.user.id, name: name.trim(), email });
      }
      notify('Account created! Welcome to Tasky.', 'success');
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Sign up failed.');
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="min-h-screen flex">
      <div className="hidden lg:flex lg:w-[54%] auth-image relative">
        <div className="absolute bottom-10 left-10 right-10 text-white max-w-md">
          <p className="font-display text-2xl font-bold leading-snug">"Small steps every day add up to big results."</p>
          <p className="mt-2 text-sm text-white/80">— Tasky</p>
        </div>
      </div>
      <div className="flex-1 lg:w-[46%] bg-[#FAF3FC] flex flex-col px-6 sm:px-12 lg:px-16 py-8">
        <div className="flex items-center gap-2">
          <div className="w-9 h-9 rounded-2xl bg-[#7653A6] flex items-center justify-center">
            <CheckCircle2 size={20} className="text-white" />
          </div>
          <span className="font-display text-xl font-extrabold text-[#292238]">Tasky</span>
        </div>
        <div className="flex-1 flex flex-col justify-center max-w-md w-full mx-auto py-8">
          <h1 className="font-display text-3xl font-extrabold text-[#292238]">Create your Tasky account ✨</h1>
          <p className="mt-2 text-[#7B6B8E]">Turn everyday tasks into small wins.</p>
          <form onSubmit={handleSubmit} className="mt-7 space-y-4">
            {error && <div className="px-4 py-3 rounded-2xl bg-[#FDECEC] text-[#C0473F] text-sm">{error}</div>}
            <Input label="Full name" name="name" placeholder="e.g. Alex Rivera" value={name} onChange={e => setName(e.target.value)} />
            <Input label="Email" name="email" type="email" placeholder="Enter your email" value={email} onChange={e => setEmail(e.target.value)} />
            <Input
              label="Password"
              name="password"
              type={showPw ? 'text' : 'password'}
              placeholder="Create a password"
              value={password}
              onChange={e => setPassword(e.target.value)}
              rightSlot={
                <button type="button" onClick={() => setShowPw(s => !s)} className="text-[#9B8BAD] hover:text-[#7653A6]" aria-label={showPw ? 'Hide password' : 'Show password'}>
                  {showPw ? <EyeOff size={18} /> : <Eye size={18} />}
                </button>
              }
            />
            {password && (
              <div className="flex flex-wrap gap-2">
                {pwChecks.map(c => (
                  <span key={c.label} className={`text-xs px-2 py-1 rounded-full ${c.ok ? 'bg-[#E8F5EC] text-[#3B7A52]' : 'bg-[#FDECEC] text-[#C0473F]'}`}>
                    {c.ok ? '✓' : '•'} {c.label}
                  </span>
                ))}
              </div>
            )}
            <Input label="Confirm password" name="confirm" type="password" placeholder="Re-enter your password" value={confirm} onChange={e => setConfirm(e.target.value)} />
            <Button type="submit" size="lg" className="w-full" disabled={loading}>
              {loading ? 'Creating account…' : 'Create account'}
            </Button>
          </form>
          <div className="flex items-center gap-3 my-6 text-xs text-[#9B8BAD]">
            <div className="flex-1 h-px bg-[#E5DBF5]" /> or continue with <div className="flex-1 h-px bg-[#E5DBF5]" />
          </div>
          <button
            onClick={() => notify('Google sign-in is ready to connect — add OAuth in Settings.', 'success')}
            className="w-full flex items-center justify-center gap-3 px-5 py-3 bg-white border border-[#E5DBF5] rounded-2xl text-sm font-semibold text-[#292238] hover:bg-[#F8F3FE] transition-colors"
          >
            <svg width="18" height="18" viewBox="0 0 24 24"><path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"/><path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"/><path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z"/><path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z"/></svg>
            Continue with Google
          </button>
          <p className="mt-6 text-center text-sm text-[#7B6B8E]">
            Already have an account?{' '}
            <button onClick={onSwitch} className="text-[#7653A6] font-semibold hover:underline">Log in</button>
          </p>
        </div>
      </div>
    </div>
  );
}
