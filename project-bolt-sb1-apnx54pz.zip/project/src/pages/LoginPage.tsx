import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Eye, EyeOff, CheckCircle2 } from 'lucide-react';
import { supabase } from '@/lib/supabase';
import { Button } from '@/components/Button';
import { Input } from '@/components/Input';
import { useToast } from '@/components/Toast';

const quotes = [
  { text: 'Give up on your dreams and die.', author: 'Levi Ackerman, Attack on Titan' },
  { text: 'The best time to plant a tree was 20 years ago. The second best time is now.', author: 'Chinese Proverb' },
  { text: 'You don\'t have to see the whole staircase, just take the first step.', author: 'Martin Luther King Jr.' },
  { text: 'It always seems impossible until it\'s done.', author: 'Nelson Mandela' },
];

export function LoginPage({ onSwitch }: { onSwitch: () => void }) {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPw, setShowPw] = useState(false);
  const [remember, setRemember] = useState(true);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [quoteIdx, setQuoteIdx] = useState(0);
  const { notify } = useToast();
  const navigate = useNavigate();

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError('');
    if (!email.includes('@')) { setError('Please enter a valid email.'); return; }
    if (password.length < 6) { setError('Password must be at least 6 characters.'); return; }
    setLoading(true);
    try {
      const { error } = await supabase.auth.signInWithPassword({ email, password });
      if (error) throw error;
      notify('Welcome back!', 'success');
      navigate('/app');
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Login failed. Check your credentials.');
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="min-h-screen flex">
      <div className="hidden lg:flex lg:w-[54%] auth-image relative">
        <div className="absolute bottom-10 left-10 right-10 text-white max-w-md">
          <p className="font-display text-2xl font-bold leading-snug">"{quotes[quoteIdx].text}"</p>
          <p className="mt-2 text-sm text-white/80">— {quotes[quoteIdx].author}</p>
          <button
            onClick={() => setQuoteIdx(i => (i + 1) % quotes.length)}
            className="mt-4 px-4 py-2 rounded-full bg-white/20 backdrop-blur text-white text-sm font-semibold hover:bg-white/30 transition-colors"
          >
            New quote
          </button>
        </div>
      </div>
      <div className="flex-1 lg:w-[46%] bg-[#FAF3FC] flex flex-col px-6 sm:px-12 lg:px-16 py-8">
        <div className="flex items-center gap-2">
          <div className="w-9 h-9 rounded-2xl bg-[#7653A6] flex items-center justify-center">
            <CheckCircle2 size={20} className="text-white" />
          </div>
          <span className="font-display text-xl font-extrabold text-[#292238]">Tasky</span>
        </div>
        <div className="flex-1 flex flex-col justify-center max-w-md w-full mx-auto py-8">
          <h1 className="font-display text-3xl font-extrabold text-[#292238]">Welcome back 👋</h1>
          <p className="mt-2 text-[#7B6B8E]">Good to see you again. Please enter your details.</p>
          <form onSubmit={handleSubmit} className="mt-7 space-y-4">
            {error && <div className="px-4 py-3 rounded-2xl bg-[#FDECEC] text-[#C0473F] text-sm">{error}</div>}
            <Input label="Email" name="email" type="email" placeholder="Enter your email" value={email} onChange={e => setEmail(e.target.value)} />
            <Input
              label="Password"
              name="password"
              type={showPw ? 'text' : 'password'}
              placeholder="••••••••"
              value={password}
              onChange={e => setPassword(e.target.value)}
              rightSlot={
                <button type="button" onClick={() => setShowPw(s => !s)} className="text-[#9B8BAD] hover:text-[#7653A6]" aria-label={showPw ? 'Hide password' : 'Show password'}>
                  {showPw ? <EyeOff size={18} /> : <Eye size={18} />}
                </button>
              }
            />
            <div className="flex items-center justify-between text-sm">
              <label className="flex items-center gap-2 cursor-pointer text-[#5B4B6E]">
                <input type="checkbox" checked={remember} onChange={e => setRemember(e.target.checked)} className="w-4 h-4 rounded accent-[#7653A6]" />
                Remember me
              </label>
              <button type="button" className="text-[#7653A6] font-semibold hover:underline">Forgot password?</button>
            </div>
            <Button type="submit" size="lg" className="w-full" disabled={loading}>
              {loading ? 'Logging in…' : 'Login'}
            </Button>
          </form>
          <div className="flex items-center gap-3 my-6 text-xs text-[#9B8BAD]">
            <div className="flex-1 h-px bg-[#E5DBF5]" /> or continue with <div className="flex-1 h-px bg-[#E5DBF5]" />
          </div>
          <button
            onClick={() => notify('Google sign-in is ready to connect — add OAuth in Settings.', 'success')}
            className="w-full flex items-center justify-center gap-3 px-5 py-3 bg-white border border-[#E5DBF5] rounded-2xl text-sm font-semibold text-[#292238] hover:bg-[#F8F3FE] transition-colors"
          >
            <svg width="18" height="18" viewBox="0 0 24 24"><path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"/><path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"/><path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z"/><path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z"/></svg>
            Continue with Google
          </button>
          <p className="mt-6 text-center text-sm text-[#7B6B8E]">
            Don't have an account?{' '}
            <button onClick={onSwitch} className="text-[#7653A6] font-semibold hover:underline">Sign up</button>
          </p>
        </div>
      </div>
    </div>
  );
}
