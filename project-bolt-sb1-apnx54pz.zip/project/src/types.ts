export type Priority = 'low' | 'medium' | 'high';

export interface Task {
  id: string;
  user_id: string;
  title: string;
  description: string;
  completed: boolean;
  priority: Priority;
  category: string;
  due_date: string | null;
  due_time: string | null;
  reminder: boolean;
  sort_order: number;
  created_at: string;
  updated_at: string;
}

export interface Category {
  id: string;
  user_id: string;
  name: string;
  icon: string;
  color: string;
  created_at: string;
}

export interface Profile {
  id: string;
  name: string;
  email: string;
  avatar_url: string | null;
  task_reminders: boolean;
  daily_summary: boolean;
  weekly_progress: boolean;
}

export type PageName = 'home' | 'tasks' | 'calendar' | 'categories' | 'progress' | 'settings';
