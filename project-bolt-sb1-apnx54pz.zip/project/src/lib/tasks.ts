import { supabase } from '@/lib/supabase';
import type { Task, Priority } from '@/types';

export async function fetchTasks(): Promise<Task[]> {
  const { data, error } = await supabase.from('tasks').select('*').order('sort_order', { ascending: true });
  if (error) throw error;
  return (data ?? []) as Task[];
}

export async function createTask(input: Partial<Task>): Promise<Task> {
  const { data, error } = await supabase.from('tasks').insert(input).select().single();
  if (error) throw error;
  return data as Task;
}

export async function updateTask(id: string, patch: Partial<Task>): Promise<Task> {
  const { data, error } = await supabase.from('tasks').update({ ...patch, updated_at: new Date().toISOString() }).eq('id', id).select().single();
  if (error) throw error;
  return data as Task;
}

export async function deleteTask(id: string): Promise<void> {
  const { error } = await supabase.from('tasks').delete().eq('id', id);
  if (error) throw error;
}

export async function reorderTasks(tasks: Task[]): Promise<void> {
  const updates = tasks.map((t, i) => ({ id: t.id, sort_order: i }));
  const { error } = await supabase.from('tasks').upsert(updates);
  if (error) throw error;
}

export const priorityRank: Record<Priority, number> = { high: 0, medium: 1, low: 2 };
